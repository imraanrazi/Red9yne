insert into Order_Status (Order_Desc) values ('Pending');
insert into Order_Status (Order_Desc) values ('In progress');
insert into Order_Status (Order_Desc) values ('Completed');


