insert into FoodType (Food_Desc) values ('Vegan');
insert into FoodType (Food_Desc) values ('Vegetarian');
insert into FoodType (Food_Desc) values ('Meat');
insert into FoodType (Food_Desc) values ('Gluten free');



