insert into Dessert (Dessert_name, Dessert_desc, Dessert_price) values ('Pudding', 'Has pudding in it','5.00');
insert into Dessert (Dessert_name, Dessert_desc, Dessert_price) values ('Ice cream', 'soft serve','10.00');
insert into Dessert (Dessert_name, Dessert_desc, Dessert_price) values ('Boba', 'Sweet','5.00');

