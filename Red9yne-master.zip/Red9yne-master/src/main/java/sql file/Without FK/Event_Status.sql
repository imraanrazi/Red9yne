insert into Event_Status (Event_Desc) values ('Wedding');
insert into Event_Status (Event_Desc) values ('Birthday');
insert into Event_Status (Event_Desc) values ('Funeral');
insert into Event_Status (Event_Desc) values ('Corperate Event');
insert into Event_Status (Event_Desc) values ('New year');
