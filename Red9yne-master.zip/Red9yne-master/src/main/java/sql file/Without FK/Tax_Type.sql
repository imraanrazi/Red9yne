insert into Tax_Type (Tax_Percentage) values ('625');
