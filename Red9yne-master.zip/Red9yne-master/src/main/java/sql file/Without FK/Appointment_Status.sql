insert into Appointment_Status (Appointment_Status) values ('Left a message');
insert into Appointment_Status (Appointment_Status) values ('Met with manager');
insert into Appointment_Status (Appointment_Status) values ('Took order');


