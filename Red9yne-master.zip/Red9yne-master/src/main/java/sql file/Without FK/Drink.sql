insert into Drink (DRINK_NAME, DRINK_DESC) values ('Coke', 'Sweet');
insert into Drink (DRINK_NAME, DRINK_DESC) values ('Sprint', 'Sweet');
insert into Drink (DRINK_NAME, DRINK_DESC) values ('Sweet tea', 'Sweet');
insert into Drink (DRINK_NAME, DRINK_DESC) values ('Lemonade', 'sour');
