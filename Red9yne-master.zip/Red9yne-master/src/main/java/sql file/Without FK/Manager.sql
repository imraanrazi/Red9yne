insert into Manager (MANAGER_FNAME, MANAGER_LNAME, MANAGER_EMAIL, MANAGER_PHONE) values ('Alameda', 'Glancy', 'aglancy0@360.cn', '581-451-6605');
